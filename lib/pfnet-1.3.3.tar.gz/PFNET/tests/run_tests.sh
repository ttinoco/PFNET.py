# run the tests with data file given (should use autotools macros)
./run_tests ../data/ieee14.mat
